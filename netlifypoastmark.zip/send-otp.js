// Sends the app-lock "forgot PIN" one-time code by email, using Resend
// (https://resend.com — free tier is plenty for this).
// Set RESEND_API_KEY in: Netlify site → Site configuration → Environment variables.

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  let to, code;
  try {
    ({ to, code } = JSON.parse(event.body));
  } catch {
    return { statusCode: 400, body: "Invalid request body" };
  }
  if (!to || !code) {
    return { statusCode: 400, body: "Missing to/code" };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        // Resend's free tier requires "from" to be onboarding@resend.dev
        // until you verify your own domain — swap this once you do.
        from: "Postmark <onboarding@resend.dev>",
        to: [to],
        subject: "Your Postmark unlock code",
        html: `<p>Your one-time code to reset your Postmark app-lock PIN is:</p>
               <p style="font-size:28px;font-weight:700;letter-spacing:6px;">${code}</p>
               <p>This code expires in 10 minutes. If you didn't request this, you can ignore this email.</p>`,
      }),
    });
    if (!res.ok) {
      const errText = await res.text();
      return { statusCode: 502, body: JSON.stringify({ ok: false, error: errText }) };
    }
    return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ok: true }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ ok: false }) };
  }
};
